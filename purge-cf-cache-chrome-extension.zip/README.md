# purge-cf-cache-chrome-extension
A chrome extension that purges the CF cache for the current URL of CloudFlare enabled websites
You can find the Chrome extension [here](https://chrome.google.com/webstore/detail/cloudflare-purge-plugin/nbpecchpcfacahhekolpaofpmogkmmok).
